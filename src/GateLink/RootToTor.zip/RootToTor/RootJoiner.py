import uproot
import glob
import os


class RootJoiner:
    def __init__(self, file_path, tree_name="Singles"):
        self.file_path = file_path
        self.tree_name = tree_name
        self._rootFiles = glob.glob(os.path.join(file_path, "*.root"))
        self._rootFiles.sort()
        self._rootFiles = [f"{el}:{tree_name}" for el in self._rootFiles]
        self._globalArray = None

    def chooseJustFilteredData(self):
        # filter files which has filtered in the late part of the name
        self._rootFiles = [el for el in self._rootFiles if "filtered" in el]
        
    def join(self):
        print("Joining root files")
        print("Number of files: ", len(self._rootFiles))
        self._globalArray = uproot.concatenate(self._rootFiles)
        try:
            del self._globalArray["comptVolName"]
            del self._globalArray["RayleighVolName"]

        except AttributeError:
            pass
        print("Saving joined root file")
        root = uproot.create(os.path.join(self.file_path, "joined.root"))

        # root[self.tree_name] = self._globalArray
        root["Singles"] = self._globalArray
        print("End of join")


if __name__ == "__main__":
    filePath = "C:\\Users\\pedro\\OneDrive - Universidade de Aveiro\\SimulacoesGATE\\EasyPET3D64\\FOV-UniformSource\\20-December-2022_17h23_8turn_0p005s_1p80bot_0p23top_range108\\"
    rootJoiner = RootJoiner(file_path=filePath, tree_name="SinglesScanner1")
    rootJoiner.chooseJustFilteredData()
    rootJoiner.join()
